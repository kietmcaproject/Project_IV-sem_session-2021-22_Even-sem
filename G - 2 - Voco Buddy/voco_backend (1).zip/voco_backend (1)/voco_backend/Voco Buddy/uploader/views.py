from django.shortcuts import render, redirect
from uploader.forms import ImageFileForm
from uploader.models import ImageFile

from django.views.generic import TemplateView


# Create your views here.

class MainPageView(TemplateView):
    template_name = 'uploader/mainpage.html'


class ContactPageView(TemplateView):
    template_name = 'uploader/contactus.html'

class DocumentationPageView(TemplateView):
    template_name = 'uploader/documentation.html'


class TestimonialPageView(TemplateView):
    template_name = 'uploader/testimonial.html'

class AboutPageView(TemplateView):
    template_name = 'uploader/about.html'


def home(request):
    data = dict()

    image_form = ImageFileForm(request.POST or None, request.FILES or None)
    if image_form.is_valid():
        image = image_form.save()
        image.execute_and_save_ocr()
        redirect('image_to_text')

    image_list = ImageFile.objects.all().order_by('-id')

    data['image_form'] = image_form
    data['image_list'] = image_list
    return render(request, "uploader/index.html", data)

def image_to_text(request):
    data = dict()

    image_form = ImageFileForm(request.POST or None, request.FILES or None)
    if image_form.is_valid():
        image = image_form.save()
        image.execute_and_save_ocr()
        redirect('image_to_text')

    image_list = ImageFile.objects.all().order_by('-id')

    data['image_form'] = image_form
    data['image_list'] = image_list
    return render(request, "uploader/image_to_text.html", data)
