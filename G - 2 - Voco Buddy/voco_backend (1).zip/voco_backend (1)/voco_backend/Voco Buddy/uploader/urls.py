"""OCR_web URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.urls import path
from uploader.views import home,image_to_text,MainPageView, ContactPageView, DocumentationPageView,TestimonialPageView,AboutPageView

urlpatterns = [
    # path('', home, name='home'),
    path('image_to_text/', image_to_text, name='image_to_text'),
    path('', MainPageView.as_view(), name='mainpage'),
    path('contactus/', ContactPageView.as_view(), name='contactus'),
    path('testimonial/', TestimonialPageView.as_view(), name='testimonial'),
    path('documentation/', DocumentationPageView.as_view(), name='documentation'),
    path('about/', AboutPageView.as_view(), name='about'),
]
