from django.apps import AppConfig


class UploaderConfig(AppConfig):
    name = 'uploader'
