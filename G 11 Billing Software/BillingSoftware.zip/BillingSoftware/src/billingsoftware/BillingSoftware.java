
package billingsoftware;

public class BillingSoftware
{
    public static void main(String[] args) 
    {
        new StartProject().setVisible(true);
    }
}
