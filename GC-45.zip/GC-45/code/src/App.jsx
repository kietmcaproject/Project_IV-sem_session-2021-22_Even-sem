import './App.css'
import { Deatils } from './components/Details';
import { Navbar } from './components/Navbar';


function App() {

    return (
        <div>
            <Navbar />
            <Deatils />
        </div>
    )
}

export default App;
