export const weatherAppAPI = "c0d290eeee9dd399b017a6d2ba64be7e";

export const googleMapAPI = "AIzaSyAq15HbfCRMW7RqNb5LUNyOLyfzpYI0wl4";