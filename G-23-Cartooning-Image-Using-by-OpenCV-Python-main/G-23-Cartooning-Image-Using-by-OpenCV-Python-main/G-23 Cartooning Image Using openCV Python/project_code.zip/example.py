from cProfile import label
from ctypes import alignment
from email.mime import image
from fileinput import filename
import imghdr
from tkinter import *
from tkinter import filedialog as fd
from tkinter import mainloop,TOP
#from tkinter.ttk import Button

import numpy as np
import os
from turtle import exitonclick
from click import open_file
import cv2
from PIL import Image
from numpy import roots
root=Tk()
#root.geometry('200X150+400+300')
root.minsize(1000,900)
root.maxsize(400,400)
#root.pack(side=TOP , pady=6)
root.title("Image_conversion_App")
root.configure(bg="#88cffa")
screen_width = root.winfo_screenwidth()
screen_height = root.winfo_screenheight()
screen_resolution = str(screen_width)+'x'+str(screen_height)

root.geometry(screen_resolution)


def Convert_to_cartoon():
    filename=fd.askopenfilename()
    Image.open(filename)
    image = cv2.imread(filename)
    resized_image = resizeImage(image)
    coloured = ColorQuantization(resized_image)
    contoured = findCountours(coloured)
    final_image= contoured
    save_q = input("save the image ? [YES]/[NO]")

    if save_q=="YES" :
        Save_image()
    
def Save_image():
    final_image = 'contoured'
    image_path = final_image
    img=cv2.imread(image_path)
    filename='savedImage.jpg'

    #final_image = contoured
    cv2.imwrite( filename, img)
    print("Saved successfully ")
    

def close_window():
    root.quit()
  

def open():
    Image.open(filename)

def resizeImage(image):
    scale_ratio = 0.30
    width = int(image.shape[1] * scale_ratio)
    height = int(image.shape[0] * scale_ratio)
    new_dimensions = (width, height)
    resized = cv2.resize(image, new_dimensions, interpolation=cv2.INTER_AREA)
    return resized

def findCountours(image):
    
    contoured_image = image
    gray = cv2.cvtColor(contoured_image, cv2.COLOR_BGR2GRAY) 
    edged = cv2.Canny(gray, 70, 80)
    contours, hierarchy = cv2.findContours(edged, 
    cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    cv2.drawContours(contoured_image, contours, contourIdx=-1, color=1, thickness=1)
    cv2.imshow('Image after countouring', contoured_image)
    cv2.waitKey(0)
    #path ="cartoonized_"+ filename
    #cv2.imwrite(path, contoured_image)

    cv2.destroyAllWindows()

    return contoured_image


def ColorQuantization(image, K=4):
    Z = image.reshape((-1, 3))
    Z = np.float32(Z)
    criteria = (cv2.TERM_CRITERIA_EPS +
                cv2.TERM_CRITERIA_MAX_ITER, 10000, 0.0001)
    compactness, label, center = cv2.kmeans(
        Z, K, None, criteria, 1, cv2.KMEANS_RANDOM_CENTERS)
    center = np.uint8(center)
    res = center[label.flatten()]
    res2 = res.reshape((image.shape))

    return res2



if __name__ == "__main__":
    Label_1=Label(root,text="Browse A file for Conversion",width=30,font=("bold",25))
    Label_1.place(x=300,y=300)
    Button(root,text="Convert the image",width=20, height=2, bg="blue", fg="black",command=Convert_to_cartoon).place(x=500,y=500)
    Button(root,text="Save the image",width=20, height=2, bg="blue", fg="black" ,command=Save_image).place(x=500,y=600)
    Button(root,text="exit",width=20, height=2, bg="blue", fg="black", command=close_window).place(x=500,y=700)
    #final_image = contoured
    save_q = input("Save the image? [y]/[n] ")

    if save_q == "y":

        #cv2.imwrite("cartoonized_"+ filename,final_image)
    
        print("Image saved!")

    root.mainloop()