package com.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/ReadyToUpdate")
public class ReadyToUpdate extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		try(PrintWriter out=response.getWriter()) {
			
				
				
				int tnum=Integer.parseInt(request.getParameter("tNum"));
				String tname=request.getParameter("tName");
				String MON=request.getParameter("MON");
				String TUE=request.getParameter("TUE");
				String WED=request.getParameter("WED");
				String THU=request.getParameter("THU");
				String FRI=request.getParameter("FRI");
				String SAT=request.getParameter("SAT");
				String SUN=request.getParameter("SUN");
			
				String sou=request.getParameter("sou");
				String souCode=request.getParameter("souCode");
				String des=request.getParameter("des");
				String desCode=request.getParameter("desCode");
				int distance=Integer.parseInt(request.getParameter("distance"));
				int days=Integer.parseInt(request.getParameter("days"));
				int btStn=Integer.parseInt(request.getParameter("btStn"));
				String sArrival=request.getParameter("sArrival");
				String sStop=request.getParameter("sStop");
				String sDeparture=request.getParameter("sDeparture");
				
				String dArrival=request.getParameter("dArrival");
				int acCoaches=Integer.parseInt(request.getParameter("acCoaches"));
				int sleeperCoaches=Integer.parseInt(request.getParameter("sleeperCoaches"));
				int generalCoaches=Integer.parseInt(request.getParameter("generalCoaches"));
				
				Class.forName("com.mysql.cj.jdbc.Driver");
				Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/rajat","root","1234");
				
				PreparedStatement ps=con.prepareStatement("update train_detail SET tname=?,MON=?,TUE=?,WED=?,THU=?,FRI=?,SAT=?,SUN=?,sou=?,souCode=?,des=?,desCode=?,distance=?,days=?,btStn=?,sArrival=?,sStop=?,sDeparture=?,dArrival=?,acCoaches=?,sleeperCoaches=?,generalCoaches=? where tnum=? ");
				
				
				ps.setString(1, tname);
				ps.setString(2, MON);
				ps.setString(3, TUE);
				ps.setString(4, WED);
				ps.setString(5, THU);
				ps.setString(6, FRI);
				ps.setString(7, SAT);
				ps.setString(8, SUN);
				
				ps.setString(9, sou);
				ps.setString(10, souCode);
				ps.setString(11, des);
				ps.setString(12, desCode);
				ps.setInt(13, distance);
				ps.setInt(14, days);
				ps.setInt(15, btStn);
				
				ps.setString(16, sArrival);
				ps.setString(17, sStop);
				ps.setString(18, sDeparture);
				ps.setString(19, dArrival);
				ps.setInt(20, acCoaches);
				ps.setInt(21, sleeperCoaches);
				ps.setInt(22, generalCoaches);
				ps.setInt(23, tnum);
				
				int status = ps.executeUpdate();
				if(status>0) {
					
					RequestDispatcher rd=request.getRequestDispatcher("dataUpdated.html");
					rd.forward(request,response);
					
				}else {
					
					RequestDispatcher rd=request.getRequestDispatcher("dataNotUpdated.html");
					rd.forward(request,response);
				}
	}catch(Exception e) {
		System.out.println("Exception is "+e);
}
		}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doGet(request, response);
	}

}
