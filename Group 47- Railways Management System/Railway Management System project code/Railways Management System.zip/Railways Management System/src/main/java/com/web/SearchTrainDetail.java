package com.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.FileSystemNotFoundException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.web.model.Train;




@WebServlet("/SearchTrainDetail")
public class SearchTrainDetail extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		try(PrintWriter out=response.getWriter()){
			int tnum=Integer.parseInt(request.getParameter("Tnumber"));
		
			String tname=request.getParameter("Tname");
	
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/rajat","root","1234");
			PreparedStatement pst = con.prepareStatement( "select * from train_detail where tnum=? or tname=?" );
			pst.setInt(1, tnum);
			pst.setString(2, tname);
			
			PreparedStatement ps = con.prepareStatement( "SELECT count(*) as total from train_detail where tnum=? or tname=?" );
			ps.setInt(1, tnum);
			ps.setString(2, tname);
			ResultSet status = ps.executeQuery();
			
			
			if(status.next()) {
				 int t = status.getInt("total");
				if(t>0) {
					ResultSet rs = pst.executeQuery();
					
		            
	            	Train ob=new Train();
	    			
	        		  while(rs.next()) {
	        			ob.setTnum(rs.getInt("tnum"));
	        			ob.setTname(rs.getString("tname"));
	        			ob.setMON(rs.getString("MON"));
	        			ob.setTUE(rs.getString("TUE"));
	        			ob.setWED(rs.getString("WED"));
	        			ob.setTHU(rs.getString("THU"));
	        			ob.setFRI(rs.getString("FRI"));
	        			ob.setSAT(rs.getString("SAT"));
	        			ob.setSUN(rs.getString("SUN"));
	        			ob.setSou(rs.getString("sou"));
	        			ob.setSouCode(rs.getString("souCode"));
	        			ob.setDes(rs.getString("des"));
	        			ob.setDesCode(rs.getString("desCode"));
	        			ob.setDistance(rs.getInt("distance"));
	        			ob.setDays(rs.getInt("days"));
	        			ob.setBtStn(rs.getInt("btStn"));
	        			ob.setsArrival(rs.getString("sArrival"));
	        			ob.setsStop(rs.getString("sStop"));
	        			ob.setsDeparture(rs.getString("sDeparture"));
	        			ob.setdArrival(rs.getString("dArrival"));
	        			ob.setAcCoaches(rs.getInt("acCoaches"));
	        			ob.setSleeperCoaches(rs.getInt("sleeperCoaches"));
	        			ob.setGeneralCoaches(rs.getInt("generalCoaches"));
	        			
	        			
	        		  }	
	                request.setAttribute("trainOb",ob);
	                request.getRequestDispatcher("SearchTrainDetail.jsp").forward(request, response);
					 
				 }else {
					 
					 RequestDispatcher rd=request.getRequestDispatcher("TrainNotFound.html");
						rd.forward(request,response);
			 }
			
				
				
				
			} 
				
		}
	catch(Exception e) {
		System.out.println("Exception is "+e);
	}
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		
		doGet(request, response);
	}

}
