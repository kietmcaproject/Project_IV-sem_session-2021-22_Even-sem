package com.web.model;

public class Train {

	private int tnum;
	private String tname;
	private String MON;
	private String TUE;
	private String WED;
	private String THU;
	private String FRI;
	private String SAT;
	private String SUN;

	private String sou;
	private String souCode;
	private String des;

	private String desCode;
	private int distance;
	private int days;
	private int btStn;

	private String sArrival;
	public Train(){
		
	}
	public Train(int Tnum,String TName) {
		this.tnum=Tnum;
		this.tname= TName;
	}
	public int getTnum() {
		return tnum;
	}
	public void setTnum(int tnum) {
		this.tnum = tnum;
	}
	public String getTname() {
		
		return tname;
	}
	public void setTname(String tname) {
		this.tname = tname;
	}
	public String getMON() {
		return MON;
	}
	public void setMON(String mON) {
		MON = mON;
	}
	public String getTUE() {
		return TUE;
	}
	public void setTUE(String tUE) {
		TUE = tUE;
	}
	public String getWED() {
		return WED;
	}
	public void setWED(String wED) {
		WED = wED;
	}
	public String getTHU() {
		return THU;
	}
	public void setTHU(String tHU) {
		THU = tHU;
	}
	public String getFRI() {
		return FRI;
	}
	public void setFRI(String fRI) {
		FRI = fRI;
	}
	public String getSAT() {
		return SAT;
	}
	public void setSAT(String sAT) {
		SAT = sAT;
	}
	public String getSUN() {
		return SUN;
	}
	public void setSUN(String sUN) {
		SUN = sUN;
	}
	public String getSou() {
		return sou;
	}
	public void setSou(String sou) {
		this.sou = sou;
	}
	public String getSouCode() {
		return souCode;
	}
	public void setSouCode(String souCode) {
		this.souCode = souCode;
	}
	public String getDes() {
		return des;
	}
	public void setDes(String des) {
		this.des = des;
	}
	public String getDesCode() {
		return desCode;
	}
	public void setDesCode(String desCode) {
		this.desCode = desCode;
	}
	public int getDistance() {
		return distance;
	}
	public void setDistance(int distance) {
		this.distance = distance;
	}
	public int getDays() {
		return days;
	}
	public void setDays(int days) {
		this.days = days;
	}
	public int getBtStn() {
		return btStn;
	}
	public void setBtStn(int btStn) {
		this.btStn = btStn;
	}
	public String getsArrival() {
		return sArrival;
	}
	public void setsArrival(String sArrival) {
		this.sArrival = sArrival;
	}
	public String getsStop() {
		return sStop;
	}
	public void setsStop(String sStop) {
		this.sStop = sStop;
	}
	public String getsDeparture() {
		return sDeparture;
	}
	public void setsDeparture(String sDeparture) {
		this.sDeparture = sDeparture;
	}
	public String getdArrival() {
		return dArrival;
	}
	public void setdArrival(String dArrival) {
		this.dArrival = dArrival;
	}
	public int getAcCoaches() {
		return acCoaches;
	}
	public void setAcCoaches(int acCoaches) {
		this.acCoaches = acCoaches;
	}
	public int getSleeperCoaches() {
		return sleeperCoaches;
	}
	public void setSleeperCoaches(int sleeperCoaches) {
		this.sleeperCoaches = sleeperCoaches;
	}
	public int getGeneralCoaches() {
		return generalCoaches;
	}
	public void setGeneralCoaches(int generalCoaches) {
		this.generalCoaches = generalCoaches;
	}
	private String sStop;
	private String sDeparture;
	private String dArrival;
	
	private int acCoaches;
	private int sleeperCoaches;
	private int generalCoaches;
	
	
	
	public void print()
	{
		System.out.println("Train Number: "+tnum+" Train Name: "+tname);
	}
}
