package com.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/AddTrainDetail")
public class AddTrainDetail extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		
		try(PrintWriter out=response.getWriter()) {
		String MON,TUE,WED,THU,FRI,SAT,SUN;
			
			
			int tnum=Integer.parseInt(request.getParameter("tNum"));
			String tname=request.getParameter("tName");
			
			if(null==request.getParameter("MON")) {
				 MON="NO";
			}else {
				 MON="YES";
				}
			
			if(null==request.getParameter("TUE")) {
				 TUE="NO";
			}else {
				  TUE="YES";
				}
			if(null==request.getParameter("WED")) {
				   WED="NO";
			}else {
				  WED="YES";
				}
			if(null==request.getParameter("THU")) {
				  THU="NO";
			}else {
				   THU="YES";
				}
			if(null==request.getParameter("FRI")) {
				  FRI="NO";
			}else {
				  FRI="YES";
				}
			if(null==request.getParameter("SAT")) {
				  SAT="NO";
			}else {
				  SAT="YES";
				}
			if(null==request.getParameter("SUN")) {
				  SUN="NO";
			}else {
				  SUN="YES";
				}
		
			String sou=request.getParameter("sou");
			String souCode=request.getParameter("souCode");
			String des=request.getParameter("des");
			String desCode=request.getParameter("desCode");
			int distance=Integer.parseInt(request.getParameter("distance"));
			int days=Integer.parseInt(request.getParameter("days"));
			int btStn=Integer.parseInt(request.getParameter("btStn"));
			String sArrival=request.getParameter("sArrival");
			String sStop=request.getParameter("sStop");
			String sDeparture=request.getParameter("sDeparture");
			
			String dArrival=request.getParameter("dArrival");
			int acCoaches=Integer.parseInt(request.getParameter("acCoaches"));
			int sleeperCoaches=Integer.parseInt(request.getParameter("sleeperCoaches"));
			int generalCoaches=Integer.parseInt(request.getParameter("generalCoaches"));
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/rajat","root","1234");
			PreparedStatement ps=con.prepareStatement("insert into train_detail value(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
			ps.setInt(1, tnum);
			ps.setString(2, tname);
			ps.setString(3, MON);
			ps.setString(4, TUE);
			ps.setString(5, WED);
			ps.setString(6, THU);
			ps.setString(7, FRI);
			ps.setString(8, SAT);
			ps.setString(9, SUN);
			
			ps.setString(10, sou);
			ps.setString(11, souCode);
			ps.setString(12, des);
			ps.setString(13, desCode);
			ps.setInt(14, distance);
			ps.setInt(15, days);
			ps.setInt(16, btStn);
			
			ps.setString(17, sArrival);
			ps.setString(18, sStop);
			ps.setString(19, sDeparture);
			ps.setString(20, dArrival);
			ps.setInt(21, acCoaches);
			ps.setInt(22, sleeperCoaches);
			ps.setInt(23, generalCoaches);
			
			int status = ps.executeUpdate();
			if(status>0) {
				
				RequestDispatcher rd=request.getRequestDispatcher("dataAdded.html");
				rd.forward(request,response);
				
			}else {
				
				RequestDispatcher rd=request.getRequestDispatcher("dataNotAdded.html");
				rd.forward(request,response);
			}
			
			
			
			
			
		 /* out.println("Train Number"+tnum);
		  out.println("\nTrain Name"+tname);
		  out.println("\nMon"+MON);
		  out.println("\nTue"+TUE);
		  out.println("\nWed"+WED);
		  out.println("\nThu"+THU);
		  out.println("\nFri"+FRI);
		  out.println("\nSat"+SAT);
		  out.println("\nSun"+SUN);
		  out.println("\nSource"+sou);
		  out.println("\nSource Code"+souCode);
		  out.println("\nDestination"+des);
		  out.println("\nDestination code"+desCode);
		  out.println("\nTotal Distance"+distance);
		  out.println("\nTotal Days"+days);
		  out.println("\nBetween Station"+btStn);
		  out.println("\nSource Arrival"+sArrival);
		  out.println("\nStop time"+sStop);
		  out.println("\nSource Departure time"+sDeparture);
		  
		  out.println("\nDestination Arrival"+dArrival);
		  out.println("\nAC coaches"+acCoaches);
		  out.println("\nSleeper Coaches"+sleeperCoaches);
		  out.println("\nGeneral Coaches"+generalCoaches);
		  */
		  
			
		
			
			
			
		}catch(Exception e) {
			System.out.println("Exception is "+e);
		}
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		doGet(request, response);
	}

}
