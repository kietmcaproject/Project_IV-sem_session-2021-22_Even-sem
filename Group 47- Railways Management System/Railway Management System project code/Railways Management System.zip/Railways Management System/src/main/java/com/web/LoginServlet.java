package com.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	
	{
		try(PrintWriter out=response.getWriter()) {
		
		String n=request.getParameter("uname");
		String p=request.getParameter("psw");
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/rajat","root","1234");
		
		PreparedStatement ps=con.prepareStatement("select uname from login where uname=? and password=?");
		ps.setString(1, n);
		ps.setString(2, p);
		
		ResultSet rs=ps.executeQuery();
		if(rs.next()) {
			RequestDispatcher rd=request.getRequestDispatcher("updateData.html");
			rd.forward(request,response);
			
		}else {
			
			RequestDispatcher rd=request.getRequestDispatcher("AdminLogin.html");
			
			rd.include(request,response);
			out.println("Wrong UserName or Password...!! ");
		}
	}catch(Exception e) {
		System.out.println("Exception is "+e);
	}
	}
	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}

}
