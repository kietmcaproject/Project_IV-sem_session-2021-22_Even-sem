package com.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/DeleteTrainDetail")
public class DeleteTrainDetail extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
	
		try(PrintWriter out=response.getWriter()){
			
			int tnum=Integer.parseInt(request.getParameter("Tnumber"));
			String tname=request.getParameter("Tname");
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/rajat","root","1234");
			PreparedStatement ps=con.prepareStatement("delete from train_detail where tnum=? or tname=?");
			ps.setInt(1, tnum);
			ps.setString(2, tname);
			
			int status = ps.executeUpdate();
			if(status>0) {
				
				RequestDispatcher rd=request.getRequestDispatcher("dataDeleted.html");
				rd.forward(request,response);
				
			}else {
				
				RequestDispatcher rd=request.getRequestDispatcher("dataNotDeleted.html");
				rd.forward(request,response);
			}
	}catch(Exception e) {
		System.out.println("Exception is "+e);
	}
	}

	
	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
